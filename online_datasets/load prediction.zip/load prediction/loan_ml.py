# import libs
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#import dataset
data = pd.read_csv('train_ctrUa4K.csv')

data['LoanAmount'].isnull()
data.dropna(how='any',inplace=True)
y = data['Loan_Status']
X = data.drop(columns=['Loan_Status','Loan_ID'],axis =1)

# separating train and test set
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.2,random_state = 0)

#encoding categorical data
from sklearn.preprocessing import LabelEncoder
encoder = LabelEncoder()
y_train = encoder.fit_transform(y_train)
y_test = encoder.fit_transform(y_test)

X_train = pd.get_dummies(X_train)
X_test = pd.get_dummies(X_test)

#training the model with logistic regression
from sklearn.linear_model import LogisticRegression
regressor = LogisticRegression(random_state =0)
regressor.fit(X_train,y_train)

#prediction
y_pred = regressor.predict(X_test)

#accuracy_check
from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_pred)


