# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 19:34:57 2020

@author: spriyadarshini
"""

import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sn

dataset = pd.read_csv('CarPrice_Assignment.csv')
dataset.shape
dataset.isnull().sum()
dataset.info()
dataset['CarName'].value_counts()

# Feature Engineering 
a=[]
b=[]
c =[]
for x in dataset['CarName']:
    a.append(x)
for i in a:
    n = i.lower()
    n=n.split(' ')    
    b.append(n[0])
    
for x in b:
    if x == 'maxda':
        c.append('mazda')
    elif x == 'porcshce':
        c.append('porsche')
    elif x == 'vokswagen':
        c.append('volkswagen')
    elif x == 'toyouta':
        c.append('toyota')
    else:
        c.append(x)

dataset['CarBrand'] = c

dataset.columns
dataset['CarBrand'].unique()
dataset['fueltype'].unique()
dataset['aspiration'].unique()
dataset['doornumber'].unique()
dataset['carbody'].unique()
dataset['drivewheel'].unique()
dataset['enginelocation'].unique()
dataset['enginetype'].unique()
dataset['cylindernumber'].unique()
dataset['fuelsystem'].unique()

dataset.drop(columns = ['car_ID','CarName'], axis = 1,inplace = True)

# building the correlation matrix
corr = dataset.corr()
f, ax = plt.subplots(figsize=(11, 9))
sn.heatmap(corr,annot = True, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})

""" We can see strong relation between citympg and highwaympg. There are few other features also that is showing strong co-relation
"""
total_dataset = pd.get_dummies(dataset)
total_dataset.drop(columns=['fueltype_gas','aspiration_turbo','doornumber_two','carbody_wagon','drivewheel_rwd','enginelocation_rear','enginetype_rotor','cylindernumber_two','fuelsystem_spfi','CarBrand_vw'],axis = 1,inplace = True)

total_dataset.shape
total_dataset.head(10)
y = total_dataset['price']
X = total_dataset.drop(columns=['price'], axis = 1)

# data split
from sklearn.model_selection import train_test_split
X_train, X_test , y_train, y_test = train_test_split(X,y,test_size = 0.2,random_state = 42)

# Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.fit_transform(X_test)

from sklearn.ensemble import RandomForestRegressor
rf = RandomForestRegressor(n_estimators =300)
rf.fit(X_train,y_train)
y_pred = rf.predict(X_test)


from sklearn.metrics import r2_score
r2_score(y_test,y_pred)
