import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('Train_SU63ISt.csv')
X = data['Datetime']
X = pd.to_timedelta(pd.to_datetime(X)).dt.total_seconds()
X= X.as_matrix(columns=None)
y = data.iloc[:,-1].values

data.isnull()
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.2,random_state =0)


from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train.reshape(len(X_train),1),y_train)


y_pred = regressor.predict(X_test.reshape(len(X_test),1))

plt.scatter(X_train,y_train,c='R')
plt.plot(X_train.reshape(len(X_train),1),regressor.predict(X_train.reshape(len(X_train),1)),c='b')
plt.title('time vs count(training set)')
plt.xlabel('time')
plt.ylabel('count')
plt.show()



plt.scatter(X_test,y_test,c='R')
plt.plot(X_train.reshape(len(X_train),1),regressor.predict(X_train.reshape(len(X_train),1)),c='b')
plt.title('time vs count(test set)')
plt.xlabel('time')
plt.ylabel('count')
plt.show()