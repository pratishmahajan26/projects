# -*- coding: utf-8 -*-
"""
Created on Wed Feb  5 16:36:31 2020

@author: spriyadarshini
"""

import pandas as pd
import numpy as np

columns=['userId','item_id','Rating','timestamp']
dataset = pd.read_csv('u.data',sep='\t',names = columns)
movie_titles = pd.read_csv('Movie_Id_Titles')

dataset.columns
dataset.isnull().sum()
# total number of users
dataset.groupby('userId')['item_id'].count()
len(dataset)

df_movie = pd.merge(dataset,movie_titles,on='item_id')

df_movie.groupby('title')['Rating'].mean().sort_values(ascending=False).head()

df_movie.groupby('title')['Rating'].count().sort_values(ascending=False).head()

df_rating = pd.DataFrame(df_movie.groupby('title')['Rating'].mean())
df_rating['num_of_ratings'] = pd.DataFrame(df_movie.groupby('title')['Rating'].count())


df_pivot=df_movie.pivot_table(index='userId',columns='title',values='Rating')

################# star-wars #################################

starwars_user_ratings = df_pivot['Star Wars (1977)']
similar_to_starwars = df_pivot.corrwith(starwars_user_ratings)

corr_starwars = pd.DataFrame(similar_to_starwars,columns=['Correlation'])
corr_starwars.dropna(inplace=True)
corr_starwars.head()

corr_starwars.sort_values(by='Correlation',ascending=False)
corr_starwars = corr_starwars.join(df_rating['num_of_ratings'])

corr_starwars[corr_starwars['num_of_ratings'] > 100].sort_values('Correlation',ascending=False).head(10)


############################ Pinocchio ##########################

Pinocchio_user_rating = df_pivot['Pinocchio (1940)']
corr_Pinocchio=df_pivot.corrwith(Pinocchio_user_rating)

df_Pinocchio = pd.DataFrame(corr_Pinocchio,columns=['Correlation'])
df_Pinocchio.dropna(inplace=True)

df_Pinocchio = df_Pinocchio.join(df_rating['num_of_ratings'])

df_Pinocchio[df_Pinocchio['num_of_ratings']> 100].sort_values('Correlation',ascending= False).head(10)