import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sn

# import the dataset
dataset = pd.read_csv('churn_data.csv')
dataset.shape
dataset.columns
dataset.describe()

# data cleaning

#removing NaN
dataset.isna().any()
dataset.isnull().any()  # both are same
dataset.isna().sum() # gives number of null or nan in each column
dataset = dataset.drop(columns = ['rewards_earned','credit_score'],axis = 1)
dataset.dropna(how='any',inplace = True)  # removed all the nan records


# core-relation matrix (only numerical columns)
dataset.drop(columns=['housing','payment_type','user','zodiac_sign','churn']).corrwith(dataset['churn']) #all features with churn
dataset.drop(columns=['housing','payment_type','user','zodiac_sign','churn']).corr() #all features with all features
dataset.drop(columns=['housing','payment_type','user','zodiac_sign','churn']).corrwith(dataset['churn']).plot.bar(
        figsize =(20,10),
        rot=45)

#co-relation matrix
corr = dataset.drop(columns=['churn','user']).corr()
plt.figure(figsize=(20,10))
sn.heatmap(corr,annot=True)


sn.set(style="white")

# Compute the correlation matrix
corr = dataset.drop(columns = ['user', 'churn']).corr()

# Generate a mask for the upper triangle
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
f, ax = plt.subplots(figsize=(18, 15))

# Generate a custom diverging colormap
cmap = sn.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sn.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})


dataset = dataset.drop(columns=['app_web_user'])

dataset.to_csv('random.csv',index=False)

dataset = pd.read_csv('random.csv')
dataset = dataset.drop(columns=['zodiac_sign','user'])

X= pd.get_dummies(dataset)
X = X.drop(columns=['churn','housing_na','payment_type_na'])
y = dataset['churn']

# feature scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)
# splitting the data
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.2,random_state=0)

#Applying Logistic Regression
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(n_jobs = -1,random_state = 0)
classifier.fit(X_train,y_train)

y_pred = classifier.predict(X_test)

# accuracy check
from sklearn.metrics import confusion_matrix,accuracy_score
cm = confusion_matrix(y_test,y_pred)
accuracy_score(y_test,y_pred)