# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 18:51:03 2019

@author: spriyadarshini
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
dataset = pd.read_csv('2015.csv')

########  DATA CLEANING  ############
dataset.isnull().sum()
dataset._RFHLTH.isnull().sum()  # label
dataset._RFHLTH.value_counts()   # imbalanced data
# removing the columns with more than 90% empty data
dataset = dataset.dropna(thresh=len(dataset)*.90,axis=1)
dataset = dataset.dropna()   # so many missing data

dataset.select_dtypes('number').columns
dataset.select_dtypes('object').columns
# removing the object columns
dataset= dataset.select_dtypes('number')
y= dataset['_RFHLTH']
X= dataset.drop(columns = ['_RFHLTH'],axis = 1)
# splitting the data
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size= 0.33,random_state = 42)

# training  the model first using decision tree
from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(random_state = 42)
classifier.fit(X_train,y_train)
classifier.tree_.node_count
classifier.tree_.max_depth
y_pred = classifier.predict(X_test)
y_proba = classifier.predict_proba(X_test)

from sklearn.metrics import accuracy_score,confusion_matrix
accuracy_score(y_test,y_pred)
cm = confusion_matrix(y_test,y_pred)

# using random forest
from sklearn.ensemble import RandomForestClassifier
random = RandomForestClassifier(n_estimators = 100,bootstrap = True,max_features = 'sqrt',
                                random_state = 42)
random.fit(X_train,y_train)
y_pred_1 = random.predict(X_test)

accuracy_score(y_test,y_pred_1)
cm = confusion_matrix(y_test,y_pred_1)

# visualise a decision tree
from sklearn.tree import export_graphviz
export_graphviz(classifier, 'tree.dot', rounded = True, 
                feature_names = ['x1', 'x2'], 
                class_names = ['0', '1'], filled = True)


