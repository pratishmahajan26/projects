#import libs
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#import dataset
dataset =pd.read_csv('iris.csv')
print(dataset.columns)
y=dataset['Species']
X=dataset.drop(['Species'],axis =1)

#Encoding categorical data
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
encoder = LabelEncoder()
y=encoder.fit_transform(y)
#onehotencoder = OneHotEncoder(categorical_features = [0])
#y = onehotencoder.fit_transform(y.reshape(len(y),1)).toarray()

#separating training and test set
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.20,random_state = 0)

#using logistic regression to train the model
from sklearn.linear_model import LogisticRegression
regressor = LogisticRegression(random_state =0)
regressor.fit(X_train,y_train)

#predicting using test result
y_pred = regressor.predict(X_test)

#confusion metrics
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test,y_pred)

#accuracy check
from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_pred)

y1= encoder.inverse_transform(y_test)


y2= encoder.inverse_transform(y_pred)

accuracy_score(y1,y2)