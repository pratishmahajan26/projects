# -*- coding: utf-8 -*-
"""
Created on Sun Dec  8 15:15:17 2019

@author: spriyadarshini
"""

# import the libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sn

# import dataset
training_set = pd.read_csv('train.csv')
test_set = pd.read_csv('test.csv')

# to check how features are related to other features 
corr = training_set.drop(columns=['SalePrice']).corr()
plt.figure(figsize=(30,10))
sn.heatmap(corr,annot=True)

# to check how features are related to target
num=training_set.select_dtypes(exclude='object')
numcorr=num.corr()
plt.figure(figsize=(30,1))
sn.heatmap(numcorr.sort_values(by=['SalePrice'], ascending=False).head(1), cmap='Blues',annot= True)
plt.title(" Numerical features correlation with the sale price", weight='bold', fontsize=18)
plt.show()

# plottig the strong relationship between saleprice and groundlevel area
plt.scatter(x=training_set['GrLivArea'],y = training_set['SalePrice'],color = 'red')
plt.xlabel('Ground Level Area')
plt.ylabel('Sale Price')
plt.title('Relation b/w grounlevelarea and saleprice')
plt.show()


# cleaning the dataset
training_set.isnull().sum()
test_set.isnull().sum()

# since both training and test data both has null value we will merge both and then do the feature cleaning
total_dataset = pd.concat((training_set,test_set), axis = 0,sort=False)
# since the index has also gotten copied from both dataset we will have to reindex
total_dataset=total_dataset.reset_index(drop= True)
y_train = training_set.iloc[:,[-1]].values
total_dataset.drop(columns=['SalePrice','Id'],axis = 1,inplace = True)
total_dataset.shape

# drop those columns that have more than 90% of null value
total_dataset=total_dataset.dropna(axis =1,thresh = len(total_dataset)* .90)
# dropped 6 columns
total_dataset.shape

# isolating the columns with null value and treating them separately
NA = total_dataset[['GarageType', 'GarageFinish', 'GarageQual', 'GarageCond','GarageYrBlt','BsmtFinType2','BsmtFinType1','BsmtCond', 'BsmtQual','BsmtExposure', 'MasVnrArea','MasVnrType','Electrical','MSZoning','BsmtFullBath','BsmtHalfBath','Utilities','Functional','Exterior1st','BsmtUnfSF','Exterior2nd','TotalBsmtSF','GarageArea','GarageCars','KitchenQual','BsmtFinSF2','BsmtFinSF1','SaleType']]
NA.shape

# isolating the categorical and numerical data
NAcat = NA.select_dtypes(include = 'object')   # categorical data
NAnum = NA.select_dtypes(exclude = 'object')   # numerical data

# filling the numerical data
# only GarageyrBlt will be filled with median . all other columns will be filled with 0 for Nan
from sklearn.preprocessing import Imputer
imputer = Imputer(strategy = "median",axis = 0)
# get index location of tGarageYrBlt
total_dataset.columns.get_loc('GarageYrBlt')    #55
total_dataset.iloc[:,55:56] = imputer.fit_transform(total_dataset.iloc[:,55:56])

for col in total_dataset.columns:
    if total_dataset[col].dtype != 'object':
        print(col)
        total_dataset[col] = total_dataset[col].fillna(0)
        
# filling the categorical data
# filled the columns with 1-2 missing data using ffill method
total_dataset['Electrical']=total_dataset['Electrical'].fillna(method='ffill')
total_dataset['SaleType']=total_dataset['SaleType'].fillna(method='ffill')
total_dataset['KitchenQual']=total_dataset['KitchenQual'].fillna(method='ffill')
total_dataset['Exterior1st']=total_dataset['Exterior1st'].fillna(method='ffill')
total_dataset['Exterior2nd']=total_dataset['Exterior2nd'].fillna(method='ffill')
total_dataset['Functional']=total_dataset['Functional'].fillna(method='ffill')
total_dataset['Utilities']=total_dataset['Utilities'].fillna(method='ffill')
total_dataset['MSZoning']=total_dataset['MSZoning'].fillna(method='ffill')
# filling the other columns with 'None'
for col in total_dataset.columns:
    if total_dataset[col].dtype == 'object':
        print(col)
        total_dataset[col] = total_dataset[col].fillna('None')
        

# FEATURE ENGINEERING
# since area is highly related to the SalesPrice . we can add all the floor area ,garage and basement area
total_dataset['TotalArea'] = total_dataset['TotalBsmtSF']+total_dataset['1stFlrSF']+total_dataset['2ndFlrSF'] + total_dataset['GrLivArea'] + total_dataset['GarageArea']
# avg of sum of year when house was build and remodled
total_dataset['Year average']= (total_dataset['YearRemodAdd']+total_dataset['YearBuilt'])/2       
# Total bathrooms in the ground floor
total_dataset['Bathrooms'] = total_dataset['FullBath'] + total_dataset['HalfBath']*.50

# Encoding the categorical data 
encoded_dataset = pd.get_dummies(total_dataset)

# seperating training and test set
training_set.shape
train= encoded_dataset[:1460] 
test_set.shape  
test = encoded_dataset[1460:]

# Finding the outliers and removing it
plt.scatter(x= training_set['GrLivArea'],y = training_set['SalePrice'],color = 'blue')
plt.xlabel('Ground Living Area')
plt.ylabel('Sale Price')
plt.title('Ground living Area- Price scatter plot')
plt.show()

plt.scatter(x= training_set['TotalBsmtSF'],y = training_set['SalePrice'],color = 'Red')
plt.xlabel('Total Basement Area')
plt.ylabel('Sale Price')
plt.title('tal Basement Area- Price scatter plot')
plt.show()

plt.scatter(x= training_set['1stFlrSF'],y = training_set['SalePrice'],color = 'Orange')
plt.xlabel('First Floor Area')
plt.ylabel('Sale Price')
plt.title('Floor Basement Area- Price scatter plot')
plt.show()


plt.scatter(x= training_set['MasVnrArea'],y = training_set['SalePrice'],color = 'Green')
plt.xlabel('Masonry veneer Area Area')
plt.ylabel('Sale Price')
plt.title('Masonry veneer Area- Price scatter plot')
plt.show()

training_set['GrLivArea'].sort_values(ascending= False).head(2)  # has two outliers at index (1298,523)
training_set['TotalBsmtSF'].sort_values(ascending= False).head(1)
training_set['1stFlrSF'].sort_values(ascending= False).head(1)
training_set['MasVnrArea'].sort_values(ascending= False).head(1)  # index 297

pos = [1298,523, 297]
train = train.drop(index= 1298)
train = train.drop(index= 523)
train = train.drop(index= 297)

target = training_set['SalePrice']
target = target.drop(index= 1298)
target = target.drop(index= 523)
target = target.drop(index= 297)

train.shape
target.shape

# split training and test data
from sklearn.model_selection import train_test_split
y = np.array(target)
X_train,X_test,y_train,y_test = train_test_split(train,y,test_size = 0.2,random_state = 42)

# Scaling the data
from sklearn.preprocessing import RobustScaler
scaler = RobustScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
validate = scaler.transform(test)

# training the model
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()


# evaluating the model using RMSE
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_squared_error
import math
#MSE = cross_val_score(regressor,X_train,y_train,cv = 5)
# meanMSE = np.mean(MSE)
# import math
# RMSE = math.sqrt(meanMSE)     #0.94
regressor.fit(X_train,y_train)
y_pred_train = regressor.predict(X_train)
y_pred_test = regressor.predict(X_test)
math.sqrt(mean_squared_error(y_train,y_pred_train))
RMSE = math.sqrt(mean_squared_error(y_test,y_pred_test)) #25908

# Ridge Regression
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import Ridge
ridge = Ridge()
params = {'alpha':[x for x in range(0,101)]}
ridge_reg = GridSearchCV(ridge,param_grid = params,cv=15)
ridge_reg.fit(X_train,y_train)
ridge_reg.best_params_

ridge_mod = Ridge(alpha = 9)
ridge_mod.fit(X_train,y_train)
y_pred_train = ridge_mod.predict(X_train)
y_pred_test = ridge_mod.predict(X_test)
from sklearn.metrics import mean_squared_error
math.sqrt(mean_squared_error(y_train,y_pred_train))
RMSE_ridge=math.sqrt(mean_squared_error(y_test,y_pred_test))   # 23842


# LASSO Regression
from sklearn.linear_model import Lasso
lasso = Lasso()
parameter={'alpha':[0.0001,0.0009,0.001,0.002,0.003,0.01,0.1,1,10,100]}
lasso_reg = GridSearchCV(lasso,param_grid = parameter,cv = 15)
lasso_reg.fit(X_train,y_train)
lasso_reg.best_params_

lasso_mod = Lasso(alpha = 100)
lasso_mod.fit(X_train,y_train)
y_pred_train = lasso_mod.predict(X_train)
y_pred_test = lasso_mod.predict(X_test)
math.sqrt(mean_squared_error(y_train,y_pred_train))
RMSE_lasso = math.sqrt(mean_squared_error(y_test,y_pred_test))



