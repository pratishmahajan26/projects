# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 14:36:57 2019

@author: spriyadarshini
"""
"""
The 10 classes are as follows:  \n",
    "0 => T-shirt/top\n",
    "1 => Trouser\n",
    "2 => Pullover\n",
    "3 => Dress\n",
    "4 => Coat\n",
    "5 => Sandal\n",
    "6 => Shirt\n",
    "7 => Sneaker\n",
    "8 => Bag\n",
    "9 => Ankle boot
    """
#import libs
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# import dataset
training = pd.read_csv('fashion-mnist_train.csv')
test = pd.read_csv('fashion-mnist_test.csv')

#Data Visualisation
import random
i = random.randint(0,60000)
plt.imshow(training.iloc[i,1:].values.reshape(28,28))
plt.title(training.iloc[i,[0]].values)

# creating training and testing dataset
X_train = training.iloc[:,1:].values
y_train = training.iloc[:,0].values
X_test = test.iloc[:,1:].values
y_test = test.iloc[:,0].values

from sklearn.model_selection import train_test_split
X_train,X_validate,y_train,y_validate = train_test_split(X_train,y_train,test_size = 0.2,random_state = 42)

# feature scaling 
X_train = X_train/255
X_test = X_test/255
X_validate = X_validate/255

# Changing the shape of matrix to the shape that can be passed to the convolution layer
#ie (rows,(28,28,1))  1: for greyscale 3: for colored picture
X_train = X_train.reshape(X_train.shape[0],28,28,1)
X_test = X_test.reshape(X_test.shape[0],28,28,1)
X_validate = X_validate.reshape(X_validate.shape[0],28,28,1)

# training the model
import keras
from keras.models import Sequential
from keras.layers import Convolution2D
from keras.layers import MaxPool2D
from keras.layers import Flatten
from keras.layers import Dense

# initialising the CNN model
classifier = Sequential()
#convolution layer
classifier.add(Convolution2D(32,3,3, input_shape = (28,28,1),activation = 'relu'))
# pooling layer
classifier.add(MaxPool2D(pool_size=(2,2)))
#Flatten
classifier.add(Flatten())
#hidden layer
classifier.add(Dense(output_dim=32 ,activation = 'relu'))
#output layer
classifier.add(Dense(output_dim = 10,activation = 'sigmoid'))
#compiling the model
classifier.compile(optimizer = 'adam',loss = 'sparse_categorical_crossentropy',metrics = ['accuracy'])

# fitting the model
classifier.fit(X_train,
               y_train,
               batch_size =512 , 
               epochs=25,
               validation_data=(X_validate,y_validate))

#prediction
y_pred = classifier.predict_classes(X_test)

#accuracy check
from sklearn.metrics import confusion_matrix, accuracy_score,classification_report

cm = confusion_matrix(y_test,y_pred)
accuracy_score(y_test,y_pred)
target_name = ['class '+str(j) for j in range(0,10)]
classification_report(y_test,y_pred,target_names=target_name)