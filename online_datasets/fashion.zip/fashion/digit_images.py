# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 20:12:14 2019

@author: spriyadarshini
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from keras.datasets import mnist
(X_train, y_train), (X_test, y_test) = mnist.load_data()

#data visualtion
import random
i = random.randint(0,X_train.shape[0])
plt.imshow(X_train[i])
plt.title(y_train[i])

#spliting training set
from sklearn.model_selection import train_test_split
X_train,X_validate,y_train,y_validate = train_test_split(X_train,y_train,test_size = 0.20,random_state = 0)

# feature scaling
X_train = X_train/255
X_validate = X_validate/255
X_test = X_test/255

# reshaping the features that convolution layer will accept
X_train = X_train.reshape(X_train.shape[0],28,28,1)
X_validate = X_validate.reshape(X_validate.shape[0],28,28,1)
X_test = X_test.reshape(X_test.shape[0],28,28,1)


#import libs needed for CNN model
import keras
from keras.models import Sequential
from keras.layers import Convolution2D
from keras.layers import MaxPool2D
from keras.layers import Flatten
from keras.layers import Dense

# initiaising the CNN model
classifier = Sequential()

#convolution layer
classifier.add(Convolution2D(32,3,3,input_shape =(28,28,1) ,activation = 'relu'))

#pooling layer
classifier.add(MaxPool2D(pool_size = (2,2)))

#Flatten
classifier.add(Flatten())

#hidden layer
classifier.add(Dense(output_dim= 32,activation = 'relu'))

#output layer
classifier.add(Dense(output_dim = 10,activation = 'sigmoid'))
#compiling the model
classifier.compile(optimizer = 'adam',loss = 'sparse_categorical_crossentropy',metrics = ['accuracy'])

# fitting the model
classifier.fit(X_train,
               y_train,
               batch_size = 512,
               epochs = 25,
               verbose= 1,
               validation_data=(X_validate,y_validate)
               )

# predicting the test result
y_pred = classifier.predict_classes(X_test)

# checking accuracy
from sklearn.metrics import confusion_matrix,accuracy_score,classification_report
cm = confusion_matrix(y_test,y_pred)

accuracy_score(y_test,y_pred)

target_names = ['class'+ str(i) for i in range(0,10)]
classification_report(y_test,y_pred,target_names = target_names)


