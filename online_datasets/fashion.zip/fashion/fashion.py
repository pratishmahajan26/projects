# 28*28 pixels means 784 small grids(working with image dataset)
"""
The 10 classes are as follows:  \n",
    "0 => T-shirt/top\n",
    "1 => Trouser\n",
    "2 => Pullover\n",
    "3 => Dress\n",
    "4 => Coat\n",
    "5 => Sandal\n",
    "6 => Shirt\n",
    "7 => Sneaker\n",
    "8 => Bag\n",
    "9 => Ankle boot
    """

# import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#import dataset
dataset_train = pd.read_csv('fashion-mnist_train.csv')
dataset_test = pd.read_csv('fashion-mnist_test.csv')
X_train = dataset_train.iloc[:,1:].values
y_train = dataset_train.iloc[:,[0]].values

# data visualisation
import random
i = random.randint(1,60000)
# plt.imshow(X_train[60,:].reshape(28,28))
label =y_train[i,0]
print(label)
plt.imshow(X_train[i,:].reshape(28,28))  # reshape we have done to show image which only understands pixel

