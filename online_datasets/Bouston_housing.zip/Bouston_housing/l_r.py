# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 16:14:32 2019

@author: spriyadarshini
"""

from sklearn.datasets import load_boston
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sn
dataset = load_boston()
dataset.keys()
dataset.feature_names
df = pd.DataFrame(data= dataset.data, columns =dataset.feature_names)
# no missing value
df.isnull().sum()
# no categorical data
df.select_dtypes(include = 'object').columns

df['price'] = dataset.target

# We will check correlation between columns

corr= df.corr()
plt.figure(figsize=(10,10))
sn.heatmap(corr,annot = True)
# checking all relation of all the features with target
sn.heatmap(corr.sort_values(by = 'price',ascending = False).head(1),annot= True)

# based on above observation RM and LSTAT are strongly related to target
# Also RAD and TAX have high multi-collinearity .we can keep either one of these

# now we will see relation between RM and target
plt.scatter(df['RM'],df['price'],color = 'Red')
plt.xlabel('average no. of rooms')
plt.ylabel('price')
plt.show()

plt.scatter(df['LSTAT'],df['price'],color = 'Blue')
plt.xlabel('lower status of population')
plt.ylabel('price')
plt.show()

# we will take only RM an LSTAT
X = df.drop(columns=['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX','AGE', 'DIS', 'RAD', 'TAX','PTRATIO', 'B','price'],axis = 1)
y= dataset.target

# splitting the training and test dataset
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.2,random_state = 42)

# scaling the sets
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)

# training the model
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train,y_train)

# predicting the model
y_pred_train = regressor.predict(X_train)
y_pred_test = regressor.predict(X_test)

# Evaluating the model
from sklearn.metrics import mean_squared_error,r2_score
import math
RMSE_train = math.sqrt(mean_squared_error(y_train,y_pred_train))
RMSE_test = math.sqrt(mean_squared_error(y_test,y_pred_test))
r2_train = r2_score(y_train, y_pred_train)
r2_test = r2_score(y_test, y_pred_test)

# Lets apply ridge regularisation and see the result
from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV
ridge = Ridge()
params = {'alpha':[x for x in range(0,101)]}
ridge_reg = GridSearchCV(ridge,param_grid = params,cv=15)
ridge_reg.fit(X_train,y_train)
ridge_reg.best_params_

ridge_mod = Ridge(alpha = 39)
ridge_mod.fit(X_train,y_train)
y_pred_train_rig = ridge_mod.predict(X_train)
y_pred_test_rig = ridge_mod.predict(X_test)

RMSE_train_rig = math.sqrt(mean_squared_error(y_train,y_pred_train_rig))
RMSE_test_rig = math.sqrt(mean_squared_error(y_test,y_pred_test_rig))
r2_train_rig = r2_score(y_train, y_pred_train_rig)
r2_test_rig = r2_score(y_test, y_pred_test_rig)


#####   POLYNOMIAL REGRESSION ################
from sklearn.preprocessing import PolynomialFeatures
poly = PolynomialFeatures(degree = 2)
X_train_poly = poly.fit_transform(X_train)
X_test_poly = poly.fit_transform(X_test)
poly_reg = LinearRegression()
poly_reg.fit(X_train_poly,y_train)
y_pred = poly_reg.predict(X_test_poly)
RMSE = math.sqrt(mean_squared_error(y_test,y_pred))
r2 = r2_score(y_test,y_pred)
