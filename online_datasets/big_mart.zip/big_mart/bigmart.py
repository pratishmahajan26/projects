import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv('Train.csv')
data.dropna(how = 'any',inplace=True)

X = data.drop(columns=['Item_Outlet_Sales','Item_Identifier','Item_Fat_Content','Item_Type','Outlet_Identifier'],axis =1)
y = data.iloc[:,-1].values
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
encoder = LabelEncoder()
X['Outlet_Size'] = encoder.fit_transform(X['Outlet_Size'])
X['Outlet_Location_Type'] = encoder.fit_transform(X['Outlet_Location_Type'])
X['Outlet_Type'] = encoder.fit_transform(X['Outlet_Type'])
onehotencoder_1 = OneHotEncoder(categorical_features = [4])
X = onehotencoder_1.fit_transform(X).toarray()
# to avoid dummy trap
X=X[:,1:]
onehotencoder_2 = OneHotEncoder(categorical_features = [6])
X = onehotencoder_2.fit_transform(X).toarray()
X=X[:,1:]


from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.25,random_state =0)

from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
sc_y = StandardScaler()

X_train = sc_X.fit_transform(X_train)
X_test = sc_X.fit_transform(X_test)
y_train = sc_X.fit_transform(y_train.reshape(len(y_train),1))
y_test = sc_X.fit_transform(y_test.reshape(len(y_test),1))



from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train,y_train)


y_pred = regressor.predict(X_test)

from sklearn.metrics import mean_squared_error
from math import sqrt

rmse_train = sqrt(mean_squared_error(y_train,regressor.predict(X_train)))
print('\nRMSE on train dataset : ', rmse_train)

rmse_test = sqrt(mean_squared_error(y_test,regressor.predict(X_test)))
print('\nRMSE on train dataset : ', rmse_test)

