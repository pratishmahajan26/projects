# -*- coding: utf-8 -*-
"""
Created on Mon Feb 10 15:38:07 2020

@author: spriyadarshini
"""
# importing the libraries
import pickle
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.preprocessing import OneHotEncoder

# importing the dataset
df = pd.read_csv("HR_comma_sep.csv")
features = df.drop('left', 1).columns

#for saving the names of the features
pickle.dump(features, open('features.pickle', 'wb'))

# Fit and save an OneHotEncoder
df.info()
columns_to_fit = ['sales', 'salary']
enc = OneHotEncoder(sparse=False).fit(df.loc[:, columns_to_fit])
# saving the encoder
pickle.dump(enc, open('encoder.pickle', 'wb'))

# Transform variables, merge with existing df and keep column names
column_names = enc.get_feature_names(columns_to_fit)
encoded_variables = pd.DataFrame(enc.transform(df.loc[:, columns_to_fit]), columns=column_names)
df = df.drop(columns_to_fit, 1)
df = pd.concat([df, encoded_variables], axis=1)

# Fit and save model
X, y = df.drop('left', 1), df.loc[:, 'left']
clf = LGBMClassifier().fit(X, y)
pickle.dump(clf, open('model.pickle', 'wb'))
    