# -*- coding: utf-8 -*-
"""
Created on Mon Feb 10 16:56:21 2020

@author: spriyadarshini
"""

import requests
to_predict_dict = {'satisfaction_level': 0.64,
                   'last_evaluation': 0.95,
                   'number_project': 4,
                   'average_montly_hours': 199,
                   'time_spend_company': 4,
                   'Work_accident': 0,
                   'promotion_last_5years': 0,
                   'sales': 'accounting',
                   'salary': 'medium'}

url = 'http://127.0.0.1:8000/predict'
r = requests.post(url,json=to_predict_dict); r.json()